<?php
/**
 * Zap client site. Fill the four DB_ values (deploy.sh does it for you).
 */
define('DB_NAME', '__DB_NAME__');
define('DB_USER', '__DB_USER__');
define('DB_PASSWORD', '__DB_PASSWORD__');
define('DB_HOST', '__DB_HOST__');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY', '|W,:c?q%?&Wl(~w}W1(M_yQo568sy>uG}UW-d<,nne@bI6DL9h]O,i(Ln[[5eeDt');
define('SECURE_AUTH_KEY', 'onCx6<rX=}u~M{vAg+(Zdj7(~92FQs<m,f{oeZ:^;VfOCR||||J}U_;b2+g![qc4');
define('LOGGED_IN_KEY', 'mI-&tg8~.f_MQ?jX5?Nd:A)pWs3fu::VVm%f_zqdq%l*ZKQAzN_jqq;o!zX6}U;p');
define('NONCE_KEY', '?;ihL$s6~V;L#tGKf[$U|QAaiRD-t:gKl]$|2$5f+0KTLR*M38mO+{*6VMV}vAKm');
define('AUTH_SALT', 'tyVq,9z.dGOz$.B*}=G8k>:%I0=BXuh#uQqoigU(]#X=]>x=1C2sZ#r9Jy)~fX5,');
define('SECURE_AUTH_SALT', 'jP2xx*8]0fx@[gAdSea}U.&^k2Rt3yqR$KF5FPqI*!a^j];ig^Z,CZ|bvY%qY@+.');
define('LOGGED_IN_SALT', 'o-.qvFOSH!v_SwedXZr~_CcRpaXe~Z6brH-Q]nl<k-JQ?g|_M7zu_@a0>0Fq-^Zo');
define('NONCE_SALT', 'Cd=snwUd::$Fk,=K5D2w{!p8T2.@j3cT@C>GV,E<G.urY:_p,O0N4PZ+mq4_RZG?');

$table_prefix = 'wp_';

define('WP_ENVIRONMENT_TYPE', 'production');
define('DISALLOW_FILE_EDIT', true);
define('WP_POST_REVISIONS', 5);
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);
define('FORCE_SSL_ADMIN', true);
/* Security headers here, not only in the plugin: a page cache (WP Rocket, nginx) serves pages without
   running WordPress, but wp-config.php still loads first on cache hits that go through advanced-cache. */
if (PHP_SAPI !== 'cli' && !headers_sent() && strpos($_SERVER['REQUEST_URI'] ?? '', '/wp-admin') !== 0) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS'] = 'on';
}

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
