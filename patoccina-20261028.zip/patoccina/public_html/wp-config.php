<?php
/**
 * Zap client site. Fill the four DB_ values (deploy.sh does it for you).
 */
define('DB_NAME', '__DB_NAME__');
define('DB_USER', '__DB_USER__');
define('DB_PASSWORD', '__DB_PASSWORD__');
define('DB_HOST', '__DB_HOST__');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY', 'Trui8JTlL$]},oWdPJHr=A_X%Sj*>DrFK8O]jvUt?RkoY-k#(.,UZ6)}hJym2Oz=');
define('SECURE_AUTH_KEY', 'OflW7e*b3?5LTPQ+Nrfk**Z]Hl@eE^@4?t|r25^b2&8{2k(&=B5V=Ji|y1QqY6,q');
define('LOGGED_IN_KEY', 'PRgSeQMrh}a$oKa8w6mfki6)e#XQ(m!~~d3WUAJYM8q=^b-x*QwgBSXWcbxv&GM%');
define('NONCE_KEY', 'uF$6,av*XytAHewI9e-WB.bIa-QP|D:_N-9W)rZo~25iq]m!E|:lg&!)5o0XZleV');
define('AUTH_SALT', 'K8ooU^G>j^-e8#@lX$)Q=0Na~Z?<Qg;tulD.{IpF)oQzbzAIeuK[*48tpNo&pH@s');
define('SECURE_AUTH_SALT', '=g}y_$cCkFwCt!GwK&Hx(FWqNVCn<sRBeE!)q@kqW|d|c!4SwE]_,*P6,Hisv}0=');
define('LOGGED_IN_SALT', '.dL9)8v,6+p2?Ie-r:oW0l([#iSdE^@uS>Rcf}HaFa3[<7+&u@l%72PdjJB+oiFL');
define('NONCE_SALT', 't4mDKWk+cf&jP^?55fo~79#fb}b(w(Ogbxh$ETv^NK^zbZaaTg8!Am:<e<A|1u3g');

$table_prefix = 'wp_';

define('WP_ENVIRONMENT_TYPE', 'production');
define('DISALLOW_FILE_EDIT', true);
define('WP_POST_REVISIONS', 5);
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);
define('FORCE_SSL_ADMIN', true);
/* Security headers here, not only in the plugin: a page cache (WP Rocket, nginx) serves pages without
   running WordPress, but wp-config.php still loads first on cache hits that go through advanced-cache. */
if (PHP_SAPI !== 'cli' && !headers_sent() && strpos($_SERVER['REQUEST_URI'] ?? '', '/wp-admin') !== 0) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS'] = 'on';
}

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
