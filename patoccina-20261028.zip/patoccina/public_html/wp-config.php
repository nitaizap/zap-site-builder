<?php
/**
 * Zap client site. Fill the four DB_ values (deploy.sh does it for you).
 */
define('DB_NAME', '__DB_NAME__');
define('DB_USER', '__DB_USER__');
define('DB_PASSWORD', '__DB_PASSWORD__');
define('DB_HOST', '__DB_HOST__');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY', 'PU7Qw}>n]p!lHF>mSg9VZvp@,k214[Cr<{0j]9SYK0rDq*{UJlZlE<lxM~=-UP$@');
define('SECURE_AUTH_KEY', 'ppsUs=-^MZZTu2cY{y(8XW6.8&T0|h|z%i%NkM}zN@71u))YgcvMEZc)LlQeo;ni');
define('LOGGED_IN_KEY', 'HX&m9)k#X90Qh{yMUGyXjeZG-cbR:$E3JduRHUpLDtV}-5J<j;6>E+@;DGCn{8IR');
define('NONCE_KEY', '&V]mbqp$2|fW,SobATavD^=*^&;5}+bO;f?RFp{R-W#He)KX.|WKf#nW8A$c[,A[');
define('AUTH_SALT', 'ax*3t<|Z=Yb%]I]huAbIn6b~ywJBLq$&DYHG(ZVUB&bR1LKA+YSc.H$UK2B7|3r|');
define('SECURE_AUTH_SALT', 'vF(&=zk,FB8$l[$+X}iyhCtk3iXuC:*7=0W.vk|#*&|()~kTt)s&8!(&+:Y0*X@Z');
define('LOGGED_IN_SALT', '}?fvFmq]rDiDTJps)$~eG*k^dL^?G_Bo,)MNtyf8{y5I4qnif<46&mta*S2r2R6C');
define('NONCE_SALT', 'tqfWKWv8mARzU23#CKczxam9u.q:JzhqlEW+XnCK>LKlulPhp)Ts)2]?CUNq)6F|');

$table_prefix = 'wp_';

define('WP_ENVIRONMENT_TYPE', 'production');
define('DISALLOW_FILE_EDIT', true);
define('WP_POST_REVISIONS', 5);
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);
define('FORCE_SSL_ADMIN', true);
/* Security headers here, not only in the plugin: a page cache (WP Rocket, nginx) serves pages without
   running WordPress, but wp-config.php still loads first on cache hits that go through advanced-cache. */
if (PHP_SAPI !== 'cli' && !headers_sent() && strpos($_SERVER['REQUEST_URI'] ?? '', '/wp-admin') !== 0) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS'] = 'on';
}

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
