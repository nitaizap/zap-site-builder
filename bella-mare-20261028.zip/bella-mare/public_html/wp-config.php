<?php
/**
 * Zap client site. Fill the four DB_ values (deploy.sh does it for you).
 */
define('DB_NAME', '__DB_NAME__');
define('DB_USER', '__DB_USER__');
define('DB_PASSWORD', '__DB_PASSWORD__');
define('DB_HOST', '__DB_HOST__');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY', '~zf&cjl6MeI&J4p0pS-|ZSsT_D}F7B}Y!q6frBWh-VDr5qCk8kz2;Z@Qz?fA$y~%');
define('SECURE_AUTH_KEY', 'H3}[8]vylKL6$#Vj5Ov2_2}C)|f4NV]xyy0uc3m7Uqz4o}J8EwVYODUKynqY9W|J');
define('LOGGED_IN_KEY', '2zWF:wjU#Z|HU;m7.ZeX&ibysq{02iKFO)!jX|KT^(oLYSkQrGimFzXmB|w(y:rc');
define('NONCE_KEY', '(j$#pbNhe5#exnB6uw8DHR8x[$v(mLOmO^XjT@Kfk+p{;6.Z,jwB:)]zrWiOK{<&');
define('AUTH_SALT', '~gK|[dUlaTyehic9?$|J{xH]aG5Yu=o]Zp=7#V#:%&|Zzh7ZuJ*rix]B21tL*%V0');
define('SECURE_AUTH_SALT', '%,oGL8uOm6_<T4<|9:n!lV>wi(;CxbxT{dig*JekSP0ldzTx(R4&YqVv)]=?Q(^?');
define('LOGGED_IN_SALT', '?=;dA|K*)6<xxhtZV0gM.PD8bv_6w$K^]9Z7U1+%Z#1<dWp+k*;#kB~D?Z%v412u');
define('NONCE_SALT', 'J,fvv8Zx~v#vJ#p4d3N^Wl*#@We9}7@r:3t>sE^D0R_WyndVu)cVQL_;?2bs5!oH');

$table_prefix = 'wp_';

define('WP_ENVIRONMENT_TYPE', 'production');
define('DISALLOW_FILE_EDIT', true);
define('WP_POST_REVISIONS', 5);
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);
define('FORCE_SSL_ADMIN', true);
/* Security headers here, not only in the plugin: a page cache (WP Rocket, nginx) serves pages without
   running WordPress, but wp-config.php still loads first on cache hits that go through advanced-cache. */
if (PHP_SAPI !== 'cli' && !headers_sent() && strpos($_SERVER['REQUEST_URI'] ?? '', '/wp-admin') !== 0) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS'] = 'on';
}

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
