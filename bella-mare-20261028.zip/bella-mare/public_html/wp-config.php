<?php
/**
 * Zap client site. Fill the four DB_ values (deploy.sh does it for you).
 */
define('DB_NAME', '__DB_NAME__');
define('DB_USER', '__DB_USER__');
define('DB_PASSWORD', '__DB_PASSWORD__');
define('DB_HOST', '__DB_HOST__');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY', '+&wz].b^Hq[K6bQ;$!0%[|2<wF-2Cm:GqY4JL$rF*LL9gp!T)M##DOK)p(kkjw=j');
define('SECURE_AUTH_KEY', '9CDN^.4h_96I8pS*o;t.JxY2*^B;[u~DoL6B8Pk^K*k-|~YzZLi@83Oii>AhDYvs');
define('LOGGED_IN_KEY', 'HeNtvjuOlRk,g7rhcvnuqpii.~RjLq|}..MaR:<;{[tdmhx=+GdKW}Hp~KSHs84P');
define('NONCE_KEY', 'xoG~?:^OY}=V4p)sO>vM=#Yk~TkK0*z!}>FGBp{[N~B0g_u+N2=uKN_2PtIwj~-G');
define('AUTH_SALT', '=jF4!l^>cu1]|u{1;wV}ql>3oZ-L:jQUYsjZbpd_$P>*TWK7R;Cl?GLD{0+~]d+,');
define('SECURE_AUTH_SALT', 'E]0QZ-VO~?(_9*WU8gUp7WcR7GO,ZyT_{.(eKQ0Z!~nl:.mC!{(5L58:$K%o|<1Y');
define('LOGGED_IN_SALT', '[-1:JoxCAJX[@w<snpSkks,U)8c[vB9t~skWVe}|A(4ZbmP2>*2_S:>vMwzB1uB^');
define('NONCE_SALT', '6asBPD&G):j_cqa=%<KdI[wn>9j3Q*AI$3=[rY]@obkBFXU56{wcnlva.H$dJ;h;');

$table_prefix = 'wp_';

define('WP_ENVIRONMENT_TYPE', 'production');
define('DISALLOW_FILE_EDIT', true);
define('WP_POST_REVISIONS', 5);
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);
define('FORCE_SSL_ADMIN', true);
/* Security headers here, not only in the plugin: a page cache (WP Rocket, nginx) serves pages without
   running WordPress, but wp-config.php still loads first on cache hits that go through advanced-cache. */
if (PHP_SAPI !== 'cli' && !headers_sent() && strpos($_SERVER['REQUEST_URI'] ?? '', '/wp-admin') !== 0) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000');
    }
}
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS'] = 'on';
}

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
